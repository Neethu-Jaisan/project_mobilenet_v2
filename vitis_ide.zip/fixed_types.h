#ifndef FIXED_TYPES_H
#define FIXED_TYPES_H

// If Vitis HLS's own headers aren't on the include path (e.g. when this
// file is compiled with plain g++ for host-side syntax checking via
// hls/mock/ap_fixed.h), MOCK_AP_FIXED lets tb.cpp / the *.cpp files build
// against a minimal stand-in with the same two-argument ap_fixed<W,I> API.
// In a real Vitis HLS run, MOCK_AP_FIXED must NOT be defined -- the real
// ap_fixed.h (bit-accurate, synthesizable) is used instead.
#ifdef MOCK_AP_FIXED
  #include "ap_fixed_mock.h"
#else
  #include <ap_fixed.h>
#endif

// data_t / weight_t: 16 total bits, 6 integer bits (including sign) ->
// 10 fractional bits, representable range approximately [-32, 32),
// resolution 2^-10 = 0.0009765625.
typedef ap_fixed<16, 6> data_t;
typedef ap_fixed<16, 6> weight_t;

// accum_t: 32 total bits, 12 integer bits -> 20 fractional bits,
// representable range approximately [-2048, 2048). Used for all
// multiply-accumulate chains so partial sums don't overflow before the
// final cast back down to data_t.
typedef ap_fixed<32, 12> accum_t;

#endif  // FIXED_TYPES_H
