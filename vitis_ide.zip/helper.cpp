// ============================================================================
// helper.cpp
// See helper.h for the fixed-point wire-format assumptions this file relies
// on (Q8.16 data_t, padded into a 32-bit DDR container).
// ============================================================================
#include "helper.h"

#include <cmath>
#include <climits>

#include "xil_cache.h"   // Xil_DCacheFlushRange, Xil_DCacheInvalidateRange

// ---------------------------------------------------------------------------
// Fixed-point conversion
// ---------------------------------------------------------------------------
fixed_t float_to_fixed(float value) {
    // Round-to-nearest to mirror the accelerator's AP_RND rounding mode.
    long scaled = lroundf(value * static_cast<float>(1 << FIXED_FRAC_BITS));

    // Saturate to mirror AP_SAT on the 24-bit logical width.
    const long lo = -(1L << (FIXED_TOTAL_BITS - 1));
    const long hi =  (1L << (FIXED_TOTAL_BITS - 1)) - 1;
    if (scaled < lo) scaled = lo;
    if (scaled > hi) scaled = hi;

    return static_cast<fixed_t>(scaled);
}

float fixed_to_float(fixed_t value) {
    return static_cast<float>(value) / static_cast<float>(1 << FIXED_FRAC_BITS);
}

// ---------------------------------------------------------------------------
// argmax / softmax / top-k
// ---------------------------------------------------------------------------
int argmax(const float* values, int n) {
    int best = 0;
    for (int i = 1; i < n; i++) {
        if (values[i] > values[best]) best = i;
    }
    return best;
}

void softmax(const float* logits, float* probs_out, int n) {
    // Numerically stable softmax: subtract the max logit before exponentiating.
    float max_val = logits[0];
    for (int i = 1; i < n; i++) {
        if (logits[i] > max_val) max_val = logits[i];
    }

    float sum = 0.0f;
    for (int i = 0; i < n; i++) {
        probs_out[i] = expf(logits[i] - max_val);
        sum += probs_out[i];
    }

    const float inv_sum = (sum > 0.0f) ? (1.0f / sum) : 0.0f;
    for (int i = 0; i < n; i++) {
        probs_out[i] *= inv_sum;
    }
}

void top_k(const float* scores, int n, int k, Prediction* out) {
    static bool used[MAX_CLASSES_SUPPORTED];
    if (n > MAX_CLASSES_SUPPORTED) n = MAX_CLASSES_SUPPORTED;  // defensive clamp

    for (int i = 0; i < n; i++) used[i] = false;

    for (int j = 0; j < k; j++) {
        int   best     = -1;
        float best_val = -3.4e38f;  // ~ -FLT_MAX

        for (int i = 0; i < n; i++) {
            if (!used[i] && scores[i] > best_val) {
                best_val = scores[i];
                best = i;
            }
        }

        if (best < 0) {
            // Fewer than k valid (unused) entries remain — pad defensively
            // rather than reading out of bounds.
            out[j].class_id    = 0;
            out[j].probability = 0.0f;
            out[j].score       = 0.0f;
            continue;
        }

        used[best] = true;
        out[j].class_id    = best;
        out[j].probability = best_val * 100.0f;  // scores[] here is a probability [0,1]
        out[j].score       = 0.0f;               // filled by caller from raw logits
    }
}

// ---------------------------------------------------------------------------
// Cache management
// ---------------------------------------------------------------------------
void cache_flush_range(const void* addr, size_t length_bytes) {
    Xil_DCacheFlushRange(reinterpret_cast<INTPTR>(addr),
                          static_cast<u32>(length_bytes));
}

void cache_invalidate_range(const void* addr, size_t length_bytes) {
    Xil_DCacheInvalidateRange(reinterpret_cast<INTPTR>(addr),
                               static_cast<u32>(length_bytes));
}

// ---------------------------------------------------------------------------
// LatencyTimer
// ---------------------------------------------------------------------------
void LatencyTimer::start() {
    XTime_GetTime(&t_start_);
}

void LatencyTimer::stop() {
    XTime_GetTime(&t_stop_);
}

uint64_t LatencyTimer::elapsed_ticks() const {
    if (t_stop_ <= t_start_) return 0;
    return static_cast<uint64_t>(t_stop_ - t_start_);
}

double LatencyTimer::elapsed_ms() const {
    return (static_cast<double>(elapsed_ticks()) / static_cast<double>(COUNTS_PER_SECOND)) * 1000.0;
}

double LatencyTimer::fps() const {
    double ms = elapsed_ms();
    return (ms > 0.0) ? (1000.0 / ms) : 0.0;
}