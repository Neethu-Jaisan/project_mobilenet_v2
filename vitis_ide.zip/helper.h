// ============================================================================
// helper.h
//
// Math, fixed-point conversion, cache-management, and latency-measurement
// utilities for the MobileNetV2 FPGA inference demo (ZCU104, psu_cortexa53_0,
// standalone / bare-metal).
//
// FIXED-POINT WIRE FORMAT — READ BEFORE DEPLOYING
// -----------------------------------------------------------------------
// The HLS accelerator's data_t is ap_fixed<24,8,AP_RND,AP_SAT>
// (top.h, hls_files/): 8 integer bits + 16 fractional bits = Q8.16.
//
// Vitis HLS cannot drive a native 24-bit AXI4 burst, so the m_axi ports
// (bundle=gmem0 / gmem1) are padded to the next power-of-two container,
// i.e. 32 bits per element, with the value held in the low 24 bits of each
// 32-bit DDR word. This file assumes that layout.
//
// >>> VERIFY THIS against your actual synthesis/co-simulation report before
// >>> trusting numeric results on real silicon. If your IP's "Interface &
// >>> Register" report shows a different container width, change
// >>> FIXED_FRAC_BITS / the fixed_t typedef below accordingly.
// ============================================================================
#ifndef HELPER_H
#define HELPER_H

#include <cstdint>
#include <cstddef>
#include "xtime_l.h"   // XTime, XTime_GetTime, COUNTS_PER_SECOND (ZynqMP global timer)

// ---------------------------------------------------------------------------
// Fixed-point <-> float conversion  (Q8.16, stored in a 32-bit container)
// ---------------------------------------------------------------------------
#define FIXED_FRAC_BITS  16
#define FIXED_INT_BITS   8
#define FIXED_TOTAL_BITS (FIXED_FRAC_BITS + FIXED_INT_BITS)  // 24 (logical width)

typedef int32_t fixed_t;   // 32-bit DDR container, low 24 bits significant

fixed_t float_to_fixed(float value);
float   fixed_to_float(fixed_t value);

// ---------------------------------------------------------------------------
// Classification result container
// ---------------------------------------------------------------------------
struct Prediction {
    int   class_id;
    float score;         // raw logit, float32 (fixed_to_float of output_class[i])
    float probability;   // softmax probability, already scaled to percent (0-100)
};

// Largest class count this translation unit's scratch buffers support.
// NUM_CLASSES (modulation_labels.h) = 181, well under this ceiling.
#define MAX_CLASSES_SUPPORTED 256

int  argmax(const float* values, int n);
void softmax(const float* logits, float* probs_out, int n);

// Selects the top `k` entries of `scores` (descending) into `out`.
// `out[i].probability` is pre-filled (percent-scaled); caller fills
// `out[i].score` from the raw logit array if it wants it too.
void top_k(const float* scores, int n, int k, Prediction* out);

// ---------------------------------------------------------------------------
// Cache management (Cortex-A53, standalone BSP)
//
// Required because the PS caches are NOT coherent with the PL's m_axi
// masters on this platform: writes to input_buffer must be flushed to DDR
// before XTop_Start(), and output_buffer must be invalidated before the PS
// re-reads what the PL wrote.
// ---------------------------------------------------------------------------
void cache_flush_range(const void* addr, size_t length_bytes);
void cache_invalidate_range(const void* addr, size_t length_bytes);

// ---------------------------------------------------------------------------
// Latency measurement (ZynqMP APU Generic Timer via XTime_GetTime)
// ---------------------------------------------------------------------------
class LatencyTimer {
public:
    void start();
    void stop();

    double   elapsed_ms() const;      // wall-clock milliseconds
    double   fps() const;             // 1000 / elapsed_ms(), 0 if not timed
    uint64_t elapsed_ticks() const;   // raw global-timer ticks (COUNTS_PER_SECOND Hz)

private:
    XTime t_start_ = 0;
    XTime t_stop_  = 0;
};

#endif // HELPER_H