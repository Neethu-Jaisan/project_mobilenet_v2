// ============================================================================
// modulation_labels.h
//
// Human-readable class labels for the MobileNetV2 FPGA classifier.
//
// NOTE: The synthesized accelerator (hls_files/top.h, FINAL_CLASSES) outputs
// 181 logits. This does NOT match the 24-class RadioML modulation set
// originally described in the project brief -- confirmed against
// golden_final_output.txt (181 lines) and testbench.cpp (FINAL_CLASSES loop
// bound). Per user direction, generic placeholder labels are used below.
//
// ACTION REQUIRED: replace MODULATION_LABELS[] with your real 181-class
// label list (in the exact class-index order used when export_hls.py wrote
// the classifier head weights) before using this for a real dissertation
// demo. Mislabeled indices will make every "Predicted Modulation" line
// wrong even though the accelerator itself is computing correctly.
// ============================================================================
#ifndef MODULATION_LABELS_H
#define MODULATION_LABELS_H

#define NUM_CLASSES 181

static const char* const MODULATION_LABELS[NUM_CLASSES] = {
    "Class_000", "Class_001", "Class_002", "Class_003", "Class_004", "Class_005",
    "Class_006", "Class_007", "Class_008", "Class_009", "Class_010", "Class_011",
    "Class_012", "Class_013", "Class_014", "Class_015", "Class_016", "Class_017",
    "Class_018", "Class_019", "Class_020", "Class_021", "Class_022", "Class_023",
    "Class_024", "Class_025", "Class_026", "Class_027", "Class_028", "Class_029",
    "Class_030", "Class_031", "Class_032", "Class_033", "Class_034", "Class_035",
    "Class_036", "Class_037", "Class_038", "Class_039", "Class_040", "Class_041",
    "Class_042", "Class_043", "Class_044", "Class_045", "Class_046", "Class_047",
    "Class_048", "Class_049", "Class_050", "Class_051", "Class_052", "Class_053",
    "Class_054", "Class_055", "Class_056", "Class_057", "Class_058", "Class_059",
    "Class_060", "Class_061", "Class_062", "Class_063", "Class_064", "Class_065",
    "Class_066", "Class_067", "Class_068", "Class_069", "Class_070", "Class_071",
    "Class_072", "Class_073", "Class_074", "Class_075", "Class_076", "Class_077",
    "Class_078", "Class_079", "Class_080", "Class_081", "Class_082", "Class_083",
    "Class_084", "Class_085", "Class_086", "Class_087", "Class_088", "Class_089",
    "Class_090", "Class_091", "Class_092", "Class_093", "Class_094", "Class_095",
    "Class_096", "Class_097", "Class_098", "Class_099", "Class_100", "Class_101",
    "Class_102", "Class_103", "Class_104", "Class_105", "Class_106", "Class_107",
    "Class_108", "Class_109", "Class_110", "Class_111", "Class_112", "Class_113",
    "Class_114", "Class_115", "Class_116", "Class_117", "Class_118", "Class_119",
    "Class_120", "Class_121", "Class_122", "Class_123", "Class_124", "Class_125",
    "Class_126", "Class_127", "Class_128", "Class_129", "Class_130", "Class_131",
    "Class_132", "Class_133", "Class_134", "Class_135", "Class_136", "Class_137",
    "Class_138", "Class_139", "Class_140", "Class_141", "Class_142", "Class_143",
    "Class_144", "Class_145", "Class_146", "Class_147", "Class_148", "Class_149",
    "Class_150", "Class_151", "Class_152", "Class_153", "Class_154", "Class_155",
    "Class_156", "Class_157", "Class_158", "Class_159", "Class_160", "Class_161",
    "Class_162", "Class_163", "Class_164", "Class_165", "Class_166", "Class_167",
    "Class_168", "Class_169", "Class_170", "Class_171", "Class_172", "Class_173",
    "Class_174", "Class_175", "Class_176", "Class_177", "Class_178", "Class_179",
    "Class_180",
};

#endif // MODULATION_LABELS_H