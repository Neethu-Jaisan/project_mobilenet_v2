// ============================================================================
// main.cpp
//
// MobileNetV2 FPGA Inference Demo — ZCU104 / psu_cortexa53_0 (standalone)
//
// Drives the "top" HLS accelerator (Vitis HLS-generated driver: xtop.h/xtop.c,
// IP instance "top_0", control base 0xB0000000 per this project's XSA) through
// one full inference: load a sample into DDR, flush caches, kick ap_start,
// poll ap_done with a timeout guard, invalidate caches, read back 181 class
// logits, and report Top-5 + PASS/FAIL over a colorized UART console.
//
// M.Tech dissertation note: this file intentionally keeps every register/
// cache/DMA-adjacent operation visible and commented rather than hiding it
// behind a "black box" helper, since the PS<->PL handshake (AXI-Lite control
// + two independent AXI4 master ports for input/output + cache coherency) is
// exactly the mechanism worth documenting in a hardware-software co-design
// writeup.
//
// !! IMPORTANT — CLASS COUNT NOTICE !!
// The HLS source (top.h) defines FINAL_CLASSES = 181, not the 24-class
// RadioML set described in the original brief. Per explicit instruction,
// this build uses all 181 classes with generic placeholder labels
// (modulation_labels.h). Replace that label table with your real class
// names, in export_hls.py's weight-export order, before treating demo
// output as meaningful.
// ============================================================================
#include <cstdio>
#include <cstring>
#include <cstdint>

#include "xtop.h"          // Generated Vitis HLS driver for IP "top_0"
#include "xil_cache.h"      // Xil_ICacheEnable/Disable, Xil_DCacheEnable/Disable
#include "xparameters.h"    // XPAR_TOP_0_DEVICE_ID and board parameters
#include "xstatus.h"        // XST_SUCCESS

#include "helper.h"
#include "uart_console.h"
#include "modulation_labels.h"
#include "sample_vector.h"

// ---------------------------------------------------------------------------
// Buffer sizing
// ---------------------------------------------------------------------------
// Input tensor:  data_t[INPUT_CHANNELS=2][INPUT_HEIGHT=32][INPUT_WIDTH=32]
//                => 2 * 32 * 32 = 2048 elements (matches m_axi depth=2048)
// Output vector: data_t[FINAL_CLASSES=181]     (matches m_axi depth=181)
#define INPUT_ELEMENTS  SAMPLE0_ELEMENTS   // 2048
#define OUTPUT_ELEMENTS NUM_CLASSES        // 181

// Polling guard for XTop_IsDone(): bounds how long main() will spin before
// declaring the accelerator hung. Tune against your actual measured latency
// (a few ms) — this default gives an extremely generous multi-second margin
// so it never fires under normal operation but still catches a genuine hang.
#define ACCEL_POLL_TIMEOUT_ITERS 20000000u

// ---------------------------------------------------------------------------
// DDR-resident I/O buffers for the accelerator.
//
// - 64-byte aligned to match the Cortex-A53 cache line size, so cache
//   flush/invalidate operations never touch neighboring unrelated data.
// - This is a bare-metal (no-MMU-remap) application: virtual address ==
//   physical address, so these pointers can be handed directly to
//   XTop_Set_input_r/XTop_Set_output_class as the DMA addresses the PL
//   masters will use.
// - Statically allocated (not malloc'd) so placement is deterministic and
//   guaranteed contiguous, which matters for the m_axi burst pattern the
//   HLS interface synthesis assumed.
// ---------------------------------------------------------------------------
static fixed_t input_buffer[INPUT_ELEMENTS]   __attribute__((aligned(64)));
static fixed_t output_buffer[OUTPUT_ELEMENTS] __attribute__((aligned(64)));

// Reused scratch buffers for the post-processing stage (avoid re-allocating
// float arrays every inference in a bare-metal, no-heap-growth environment).
static float logits_f[OUTPUT_ELEMENTS];
static float probs_f[OUTPUT_ELEMENTS];

static XTop accel;

// ---------------------------------------------------------------------------
// init_accelerator
//
// Brings up the XTop driver instance against the IP the platform's XSA
// describes as "top_0". Uses the classic (non system-device-tree) Vitis
// standalone flow: XTop_Initialize(InstancePtr, DeviceId).
//
// If your platform was built with the System Device Tree (SDT) flow
// instead, xtop.h exposes XTop_Initialize(InstancePtr, UINTPTR BaseAddress)
// under #ifdef SDT — swap the call below for that variant and pass
// XPAR_TOP_0_BASEADDR (or your generated equivalent) directly.
// ---------------------------------------------------------------------------
static bool init_accelerator() {
    int status = XTop_Initialize(&accel, XPAR_TOP_0_DEVICE_ID);
    if (status != XST_SUCCESS) {
        console_print_error("XTop_Initialize failed - check XPAR_TOP_0_DEVICE_ID and hardware bring-up (bitstream loaded? XSA matches app?)");
        return false;
    }

    // Explicit per-inference control: we call XTop_Start() ourselves each
    // loop iteration rather than letting the IP auto-restart, so the demo
    // can measure clean per-inference latency and detect a hang precisely.
    XTop_DisableAutoRestart(&accel);
    return true;
}

// ---------------------------------------------------------------------------
// load_sample
//
// Copies the embedded, HLS-cosim-verified test vector (sample_vector.h,
// generated from this project's own hls_input_test.txt) into the DDR input
// buffer. In a fielded demo this is the natural place to swap in a live
// I/Q capture source (e.g. an SDR front end streaming into DDR via a
// separate DMA) — the accelerator-facing contract (flush -> start -> poll
// -> invalidate) below does not change.
// ---------------------------------------------------------------------------
static void load_sample() {
    memcpy(input_buffer, SAMPLE0_IQ_FIXED, sizeof(input_buffer));
}

// ---------------------------------------------------------------------------
// run_inference
//
// Executes exactly one accelerator invocation:
//   1. Flush input DDR region from PS caches (PL must see fresh data).
//   2. Invalidate output DDR region (discard stale PS cache lines before
//      the PL writes there, so a later read can't return old data).
//   3. Program the two AXI4 master base addresses via the generated driver.
//   4. Start the IP, poll ap_done with a timeout.
//   5. Invalidate the output region again post-completion (the PL's
//      writes may not be visible to PS caches yet even though ap_done
//      is asserted -- always invalidate AFTER, not just before).
//
// Returns false on timeout; caller decides how to recover.
// ---------------------------------------------------------------------------
static bool run_inference(double* latency_ms_out, uint64_t* ticks_out) {
    cache_flush_range(input_buffer, sizeof(input_buffer));
    cache_invalidate_range(output_buffer, sizeof(output_buffer));

    XTop_Set_input_r(&accel, (u64)(uintptr_t)input_buffer);
    XTop_Set_output_class(&accel, (u64)(uintptr_t)output_buffer);

    LatencyTimer timer;
    timer.start();
    XTop_Start(&accel);

    uint32_t iters = 0;
    while (!XTop_IsDone(&accel)) {
        if (++iters > ACCEL_POLL_TIMEOUT_ITERS) {
            timer.stop();
            console_print_error("Accelerator TIMEOUT waiting for ap_done");
            console_print_accel_status(&accel);
            console_print_register_dump(&accel);
            return false;
        }
    }
    timer.stop();

    cache_invalidate_range(output_buffer, sizeof(output_buffer));

    *latency_ms_out = timer.elapsed_ms();
    *ticks_out      = timer.elapsed_ticks();
    return true;
}

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------
int main() {
    // ---- Platform bring-up -------------------------------------------------
    Xil_ICacheEnable();
    Xil_DCacheEnable();

    uart_console_init();
    console_print_banner();
    console_print_status("Platform Initialized");

    if (!init_accelerator()) {
        // Fatal: without the accelerator there is no demo to run.
        Xil_DCacheDisable();
        Xil_ICacheDisable();
        return -1;
    }
    console_print_status("Accelerator Initialized");

    // ---- Continuous inference loop -----------------------------------------
    bool quit_requested = false;

    while (!quit_requested) {
        load_sample();
        console_print_status("Input Sample Loaded");

        printf("Running inference...\r\n");

        double   latency_ms = 0.0;
        uint64_t ticks      = 0;
        bool ok = run_inference(&latency_ms, &ticks);

        if (!ok) {
            // Error already reported inside run_inference(). Give the
            // operator a chance to quit before retrying rather than
            // spinning silently on a hung IP.
            console_print_divider();
            quit_requested = console_check_quit();
            continue;
        }

        printf("Done\r\n");
        console_print_latency(latency_ms, (latency_ms > 0.0) ? (1000.0 / latency_ms) : 0.0, ticks);

        // ---- Post-processing: fixed-point -> float -> softmax -> Top-5 ----
        for (int i = 0; i < OUTPUT_ELEMENTS; i++) {
            logits_f[i] = fixed_to_float(output_buffer[i]);
        }
        softmax(logits_f, probs_f, OUTPUT_ELEMENTS);

        Prediction top5[5];
        top_k(probs_f, OUTPUT_ELEMENTS, 5, top5);
        for (int i = 0; i < 5; i++) {
            top5[i].score = logits_f[top5[i].class_id];
        }

        const int ground_truth_class = SAMPLE0_GROUND_TRUTH_CLASS;
        console_print_top5(top5, ground_truth_class);

        // ---- Hardware status / debug visibility ----
        console_print_accel_status(&accel);

        console_print_divider();
        console_print_waiting();

        quit_requested = console_check_quit();
    }

    printf("\r\n[INFO] 'q' received - shutting down demo.\r\n");

    Xil_DCacheDisable();
    Xil_ICacheDisable();
    return 0;
}