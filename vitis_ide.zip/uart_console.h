// ============================================================================
// uart_console.h
//
// All UART presentation logic for the live demo lives here, separated from
// main.cpp's control flow so the "product" look-and-feel (banner, colors,
// table layout) can be iterated on without touching the inference pipeline.
//
// ANSI escape codes are used for color. Any standard serial terminal used
// for Vitis UART consoles (PuTTY, TeraTerm, minicom, screen, the Vitis
// Serial Terminal view) supports them. Set UART_CONSOLE_USE_COLOR to 0
// below to fall back to plain text on terminals that don't.
// ============================================================================
#ifndef UART_CONSOLE_H
#define UART_CONSOLE_H

#include <cstdint>
#include "xtop.h"
#include "helper.h"

#define UART_CONSOLE_USE_COLOR 1

// ---- Console lifecycle -----------------------------------------------------
// Confirms the UART link is alive. On this platform UART stdout is already
// wired up by the standalone BSP (init_platform() from the Vitis platform
// component / lscript.ld console redirection), so this does not reconfigure
// the UART itself — it exists as an explicit, visible init step and a hook
// point if you later swap in a manually-driven XUartPs instance.
void uart_console_init();

// ---- Static / framing output ----------------------------------------------
void console_print_banner();
void console_print_divider();
void console_print_section(const char* title);
void console_print_status(const char* label);
void console_print_error(const char* message);
void console_print_waiting();

// ---- Accelerator introspection ---------------------------------------------
// Prints AP_IDLE / AP_DONE / AP_READY as reported by the generated driver.
void console_print_accel_status(XTop* accel);

// Dumps raw AXI-Lite control-register values (ap_ctrl, GIE, IER, ISR) for
// hardware-level debugging. Offsets come from the Vitis-generated
// xtop_hw.h for this exact IP build — see that file if you regenerate the
// accelerator and the register map shifts.
void console_print_register_dump(XTop* accel);

// ---- Results presentation ---------------------------------------------------
void console_print_latency(double latency_ms, double fps, uint64_t timer_ticks);

// top5 must be sorted descending (index 0 = highest probability).
// predicted_class is taken as top5[0].class_id by the caller convention
// used in main.cpp; ground_truth_class enables the PASS/FAIL banner.
void console_print_top5(const Prediction top5[5], int ground_truth_class);

// ---- Input ------------------------------------------------------------------
// Non-blocking poll for a single 'q'/'Q' keypress over UART RX.
// Returns true exactly once when 'q' is seen, false otherwise (including
// when no byte is waiting). Safe to call every loop iteration.
bool console_check_quit();

#endif // UART_CONSOLE_H