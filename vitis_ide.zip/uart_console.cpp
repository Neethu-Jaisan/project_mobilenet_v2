// ============================================================================
// uart_console.cpp
// ============================================================================
#include "uart_console.h"
#include "modulation_labels.h"

#include <cstdio>

#include "xtop_hw.h"      // XTOP_CONTROL_ADDR_* register offsets for this IP build
#include "xparameters.h"  // board/platform-generated UART base address macro
#include "xuartps_hw.h"   // XUartPs_IsReceiveData / XUartPs_RecvByte (register-level, no instance needed)

// ---------------------------------------------------------------------------
// UART base address for the non-blocking 'q' quit-key poll.
//
// ASSUMPTION: this project's stdout UART is PS UART0 at the standard
// Xilinx-generated macro name. Vitis platforms name this differently
// depending on board/BSP revision (commonly XPAR_XUARTPS_0_BASEADDR,
// occasionally XPAR_PSU_UART_0_BASEADDR on some ZynqMP BSPs).
//
// >>> If this file fails to compile with "XPAR_XUARTPS_0_BASEADDR
// >>> undeclared", open your project's xparameters.h, find the UART entry
// >>> that matches your stdout console, and update the macro below.
// ---------------------------------------------------------------------------
#ifndef UART_CONSOLE_BASEADDR
#define UART_CONSOLE_BASEADDR XPAR_XUARTPS_0_BASEADDR
#endif

// ---------------------------------------------------------------------------
// ANSI color codes
// ---------------------------------------------------------------------------
#if UART_CONSOLE_USE_COLOR
    #define C_RESET  "\033[0m"
    #define C_BOLD   "\033[1m"
    #define C_RED    "\033[1;31m"
    #define C_GREEN  "\033[1;32m"
    #define C_YELLOW "\033[1;33m"
    #define C_BLUE   "\033[1;34m"
    #define C_CYAN   "\033[1;36m"
#else
    #define C_RESET  ""
    #define C_BOLD   ""
    #define C_RED    ""
    #define C_GREEN  ""
    #define C_YELLOW ""
    #define C_BLUE   ""
    #define C_CYAN   ""
#endif

// ---------------------------------------------------------------------------
void uart_console_init() {
    // stdout is already routed to UART by the standalone BSP's console
    // redirection (see main.cpp init note). This call is an explicit,
    // visible lifecycle step and a hook point for a manual XUartPs_CfgInitialize
    // sequence if a project later needs non-default UART settings.
    printf("\r\n");
}

void console_print_banner() {
    printf("\r\n");
    printf(C_BLUE "====================================================" C_RESET "\r\n");
    printf(C_BLUE "        MobileNetV2 FPGA Inference Demo" C_RESET "\r\n");
    printf(C_BLUE "        ZCU104" C_RESET "\r\n");
    printf(C_BLUE "====================================================" C_RESET "\r\n");
}

void console_print_divider() {
    printf("--------------------------------------\r\n");
}

void console_print_section(const char* title) {
    printf(C_CYAN "--------------------------------------" C_RESET "\r\n");
    printf(C_CYAN "%s" C_RESET "\r\n", title);
    printf(C_CYAN "--------------------------------------" C_RESET "\r\n");
}

void console_print_status(const char* label) {
    printf("%s\r\n", label);
}

void console_print_error(const char* message) {
    printf(C_RED "[ERROR] %s" C_RESET "\r\n", message);
}

void console_print_waiting() {
    printf(C_YELLOW "Waiting for next sample..." C_RESET "\r\n");
}

void console_print_accel_status(XTop* accel) {
    u32 idle  = XTop_IsIdle(accel);
    u32 done  = XTop_IsDone(accel);
    u32 ready = XTop_IsReady(accel);
    printf("Accelerator Status : AP_IDLE=%u  AP_DONE=%u  AP_READY=%u\r\n",
           (unsigned)idle, (unsigned)done, (unsigned)ready);
}

void console_print_register_dump(XTop* accel) {
    u32 ap_ctrl = XTop_ReadReg(accel->Control_BaseAddress, XTOP_CONTROL_ADDR_AP_CTRL);
    u32 gie     = XTop_ReadReg(accel->Control_BaseAddress, XTOP_CONTROL_ADDR_GIE);
    u32 ier     = XTop_ReadReg(accel->Control_BaseAddress, XTOP_CONTROL_ADDR_IER);
    u32 isr     = XTop_ReadReg(accel->Control_BaseAddress, XTOP_CONTROL_ADDR_ISR);

    printf("---- Register Dump (control base 0x%016llX) ----\r\n",
           (unsigned long long)accel->Control_BaseAddress);
    printf("  AP_CTRL (0x00) = 0x%08X  [ap_start=%d ap_done=%d ap_idle=%d ap_ready=%d auto_restart=%d]\r\n",
           ap_ctrl,
           (ap_ctrl >> 0) & 0x1, (ap_ctrl >> 1) & 0x1,
           (ap_ctrl >> 2) & 0x1, (ap_ctrl >> 3) & 0x1,
           (ap_ctrl >> 7) & 0x1);
    printf("  GIE     (0x04) = 0x%08X\r\n", gie);
    printf("  IER     (0x08) = 0x%08X\r\n", ier);
    printf("  ISR     (0x0c) = 0x%08X\r\n", isr);
}

void console_print_latency(double latency_ms, double fps, uint64_t timer_ticks) {
    printf("Latency : %.2f ms\r\n", latency_ms);
    printf("FPS : %.1f\r\n", fps);
    printf("Timer Ticks : %llu (global timer, COUNTS_PER_SECOND clock domain)\r\n",
           (unsigned long long)timer_ticks);
}

void console_print_top5(const Prediction top5[5], int ground_truth_class) {
    console_print_section("Top-5 Predictions");

    for (int i = 0; i < 5; i++) {
        int cls = top5[i].class_id;
        const char* label = (cls >= 0 && cls < NUM_CLASSES) ? MODULATION_LABELS[cls] : "UNKNOWN";
        printf("%d. %-10s %6.2f %%\r\n", i + 1, label, top5[i].probability);
    }

    int predicted_class = top5[0].class_id;
    const char* predicted_label =
        (predicted_class >= 0 && predicted_class < NUM_CLASSES) ? MODULATION_LABELS[predicted_class] : "UNKNOWN";
    const char* truth_label =
        (ground_truth_class >= 0 && ground_truth_class < NUM_CLASSES) ? MODULATION_LABELS[ground_truth_class] : "UNKNOWN";

    printf("Predicted Modulation\r\n");
    printf(">>> %s\r\n", predicted_label);
    printf("Ground Truth\r\n");
    printf(">>> %s\r\n", truth_label);

    printf("Classification\r\n");
    if (predicted_class == ground_truth_class) {
        printf(C_GREEN "PASS" C_RESET "\r\n");
    } else {
        printf(C_RED "FAIL" C_RESET "\r\n");
    }
}

bool console_check_quit() {
    if (XUartPs_IsReceiveData(UART_CONSOLE_BASEADDR)) {
        u8 c = XUartPs_RecvByte(UART_CONSOLE_BASEADDR);
        if (c == 'q' || c == 'Q') {
            return true;
        }
    }
    return false;
}