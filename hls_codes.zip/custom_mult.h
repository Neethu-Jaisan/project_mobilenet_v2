#ifndef CUSTOM_MULT_H
#define CUSTOM_MULT_H

#include "common.h"

// This signature must match the port names and widths in comp_mag_mult.v
void comp_mag_mult(data_t a, data_t b, data_t &out);

#endif