// =====================================================================
// bottleneck.h - MobileNetV2 Inverted Residual Bottleneck template
//   Structure: 1x1 expand -> 3x3 depthwise (stride s) -> 1x1 project
//              + optional residual add (when stride==1 && in_c==out_c)
// =====================================================================
#ifndef BOTTLENECK_H
#define BOTTLENECK_H

#include "common.h"
#include "layers.h"

// IN_H/IN_W : input spatial dims
// IN_C      : input channels
// EXP_C     : expanded channels (IN_C * expand_ratio)
// OUT_C     : output (projected) channels
// K         : depthwise kernel size (usually 3)
// STRIDE    : depthwise stride (1 or 2)
// HAS_RESIDUAL : true only if STRIDE==1 && IN_C==OUT_C
template<int IN_H, int IN_W, int IN_C, int EXP_C, int OUT_C,
         int K, int STRIDE, bool HAS_RESIDUAL>
void bottleneck_layer(
    hls::stream<data_t> &in_stream,
    hls::stream<data_t> &out_stream,
    const weight_t w_expand[EXP_C][IN_C],
    const data_t   b_expand[EXP_C],
    const weight_t w_dw[EXP_C][K][K],
    const data_t   b_dw[EXP_C],
    const weight_t w_project[OUT_C][EXP_C],
    const data_t   b_project[OUT_C])
{
    #pragma HLS DATAFLOW

    const int DW_OUT_H = (IN_H - K) / STRIDE + 1;
    const int DW_OUT_W = (IN_W - K) / STRIDE + 1;

    // Internal FIFOs between sub-stages
    static hls::stream<data_t> in_a("bn_in_a");
    static hls::stream<data_t> in_b("bn_in_b");
    static hls::stream<data_t> expanded("bn_expanded");
    static hls::stream<data_t> dw_out("bn_dw_out");
    static hls::stream<data_t> projected("bn_projected");

    #pragma HLS STREAM variable=in_a       depth=4
    #pragma HLS STREAM variable=in_b       depth=IN_H*IN_W*IN_C
    #pragma HLS STREAM variable=expanded   depth=4
    #pragma HLS STREAM variable=dw_out     depth=4
    #pragma HLS STREAM variable=projected  depth=4

    if (HAS_RESIDUAL) {
        // Split input: one copy feeds the conv chain, one is held for residual
        stream_split<IN_H, IN_W, IN_C>(in_stream, in_a, in_b);
    }

    hls::stream<data_t> &conv_in = HAS_RESIDUAL ? in_a : in_stream;

    // 1. Expand (1x1 conv: IN_C -> EXP_C)
    pointwise_conv2d_layer<IN_H, IN_W, IN_C, EXP_C>(
        conv_in, expanded, w_expand, b_expand);

    // 2. Depthwise (KxK, stride S, per-channel)
    depthwise_conv2d_layer<IN_H, IN_W, EXP_C, K, STRIDE>(
        expanded, dw_out, w_dw, b_dw);

    // 3. Project (1x1 conv: EXP_C -> OUT_C)
    pointwise_conv2d_layer<DW_OUT_H, DW_OUT_W, EXP_C, OUT_C>(
        dw_out, projected, w_project, b_project);

    // 4. Residual add (only when shapes match)
    if (HAS_RESIDUAL) {
        residual_add_layer<DW_OUT_H, DW_OUT_W, OUT_C>(in_b, projected, out_stream);
    } else {
        // Passthrough copy
        const int N = DW_OUT_H * DW_OUT_W * OUT_C;
        for (int i = 0; i < N; i++) {
            #pragma HLS PIPELINE II=1
            out_stream.write(projected.read());
        }
    }
}

#endif // BOTTLENECK_H