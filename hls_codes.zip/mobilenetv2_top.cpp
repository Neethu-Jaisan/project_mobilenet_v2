// =====================================================================
// mobilenetv2_top.cpp - Top-level orchestrator
//   Note: dims below are illustrative (input 224x224x3). Replace per-
//   stage H/W/C constants with values matching your weights.h export.
// =====================================================================
#include "common.h"
#include "layers.h"
#include "bottleneck.h"
#include "weights.h"

// -------------------------------------------------------------
// Top-level dataflow: stem conv -> bottleneck chain -> head
// -------------------------------------------------------------
extern "C" void mobilenetv2_top(
    hls::stream<data_t> &input_stream,
    hls::stream<data_t> &output_stream)
{
    #pragma HLS INTERFACE axis port=input_stream
    #pragma HLS INTERFACE axis port=output_stream
    #pragma HLS INTERFACE s_axilite port=return

    #pragma HLS DATAFLOW

    // ---- BRAM mapping for all weight tables ----
    // Each weight array bound to its own BRAM bank for parallel access.
    #pragma HLS BIND_STORAGE variable=W_STEM      type=rom_2p impl=bram
    #pragma HLS BIND_STORAGE variable=B_STEM      type=rom_1p impl=bram
    #pragma HLS BIND_STORAGE variable=W_BN1_EXP   type=rom_2p impl=bram
    #pragma HLS BIND_STORAGE variable=W_BN1_DW    type=rom_2p impl=bram
    #pragma HLS BIND_STORAGE variable=W_BN1_PROJ  type=rom_2p impl=bram

    // Partition output-channel dim of pointwise weights for MAC parallelism
    #pragma HLS ARRAY_PARTITION variable=W_BN1_EXP  dim=1 type=cyclic factor=8
    #pragma HLS ARRAY_PARTITION variable=W_BN1_PROJ dim=1 type=cyclic factor=8
    // Partition channel dim of depthwise weights (matches DW unroll)
    #pragma HLS ARRAY_PARTITION variable=W_BN1_DW   dim=1 type=cyclic factor=8

    // ---- Inter-stage FIFOs ----
    static hls::stream<data_t> stem_out("stem_out");
    static hls::stream<data_t> bn1_out ("bn1_out");
    static hls::stream<data_t> bn2_out ("bn2_out");
    // ... add one stream per bottleneck stage in your sequence

    #pragma HLS STREAM variable=stem_out depth=112*112*32
    #pragma HLS STREAM variable=bn1_out  depth=112*112*16
    #pragma HLS STREAM variable=bn2_out  depth=56*56*24

    // ---- Stage 1: Stem conv (224x224x3 -> 112x112x32, K=3, stride=2) ----
    conv2d_layer<224, 224, 3, 32, 3, 2>(
        input_stream, stem_out, W_STEM, B_STEM);

    // ---- Stage 2: Bottleneck 1 (no residual: in_c != out_c) ----
    // expand_ratio=1 -> EXP_C == IN_C for the first block
    bottleneck_layer<112, 112, 32, 32, 16, 3, 1, false>(
        stem_out, bn1_out,
        W_BN1_EXP, B_BN1_EXP,
        W_BN1_DW,  B_BN1_DW,
        W_BN1_PROJ, B_BN1_PROJ);

    // ---- Stage 3: Bottleneck 2 (stride 2, downsample, no residual) ----
    bottleneck_layer<112, 112, 16, 96, 24, 3, 2, false>(
        bn1_out, bn2_out,
        W_BN2_EXP, B_BN2_EXP,
        W_BN2_DW,  B_BN2_DW,
        W_BN2_PROJ, B_BN2_PROJ);

    // ---- Continue chaining remaining bottlenecks identically ----
    // For stride==1 && in_c==out_c stages, set HAS_RESIDUAL=true, e.g.:
    //
    // bottleneck_layer<56, 56, 24, 144, 24, 3, 1, true>(
    //     bn2_out, bn3_out,
    //     W_BN3_EXP, B_BN3_EXP, W_BN3_DW, B_BN3_DW, W_BN3_PROJ, B_BN3_PROJ);
    //
    // ... repeat for all 17 bottleneck blocks per MobileNetV2 spec,
    // ending with the final 1x1 conv (head), global avg pool, and
    // classifier, each as its own modular function feeding output_stream.

    // ---- Final stage: write classifier output to output_stream ----
    // pointwise_conv2d_layer<...>(..., output_stream, ...);
}