// =====================================================================
// common.h - Shared types, configs, and replaceable math primitives
// =====================================================================
#ifndef COMMON_H
#define COMMON_H

#include <ap_fixed.h>
#include <hls_stream.h>

typedef ap_fixed<16, 8> data_t;
typedef ap_fixed<32, 16> acc_t;   // wider accumulator to avoid overflow
typedef ap_fixed<16, 8> weight_t;

// NOTE: Multiplication is done directly (a * b) at each call site in
// layers.h / bottleneck.h. No wrapper function is used here — this is
// intentional for this build. An approximate-multiplier RTL block will
// be integrated separately later.

// Generic 3D tile descriptor passed between layers (compile-time dims)
template<int H, int W, int C>
struct FeatureMap {
    static const int HEIGHT = H;
    static const int WIDTH  = W;
    static const int CHANS  = C;
};

#endif // COMMON_H