// =====================================================================
// layers.h - Modular layer kernels (conv2d, depthwise, pointwise)
// =====================================================================
#ifndef LAYERS_H
#define LAYERS_H

#include "common.h"
#include <hls_stream.h>

// ---------------------------------------------------------------
// Standard Conv2D (used for stem layer, stride 1 or 2, KxK kernel)
// PAD is explicit (standard MobileNetV2 uses PAD = (K-1)/2 so that
// stride-1 layers preserve H/W and stride-2 layers halve them).
// ---------------------------------------------------------------
template<int IN_H, int IN_W, int IN_C, int OUT_C, int K, int STRIDE, int PAD>
void conv2d_layer(
    hls::stream<data_t> &in_stream,
    hls::stream<data_t> &out_stream,
    const weight_t weights[OUT_C][IN_C][K][K],
    const data_t bias[OUT_C])
{
    const int PAD_H = IN_H + 2 * PAD;
    const int PAD_W = IN_W + 2 * PAD;
    const int OUT_H = (IN_H + 2 * PAD - K) / STRIDE + 1;
    const int OUT_W = (IN_W + 2 * PAD - K) / STRIDE + 1;

    data_t in_buf[IN_C][PAD_H][PAD_W];
    #pragma HLS BIND_STORAGE variable=in_buf type=ram_2p impl=bram
    #pragma HLS ARRAY_PARTITION variable=in_buf dim=1 type=complete

    // Fill buffer from the stream, zero-padding the border. Loop order
    // (c, h, w) matches the order the upstream layer wrote the stream in,
    // so the stream is read exactly once per real (non-pad) element.
    for (int c = 0; c < IN_C; c++) {
        for (int h = 0; h < PAD_H; h++) {
            for (int w = 0; w < PAD_W; w++) {
                #pragma HLS PIPELINE II=1
                bool is_pad = (h < PAD) || (h >= PAD + IN_H) ||
                              (w < PAD) || (w >= PAD + IN_W);
                in_buf[c][h][w] = is_pad ? (data_t)0 : in_stream.read();
            }
        }
    }

    for (int oc = 0; oc < OUT_C; oc++) {
        for (int oh = 0; oh < OUT_H; oh++) {
            for (int ow = 0; ow < OUT_W; ow++) {
                #pragma HLS PIPELINE II=1
                acc_t acc = bias[oc];
                for (int ic = 0; ic < IN_C; ic++) {
                    for (int kh = 0; kh < K; kh++) {
                        for (int kw = 0; kw < K; kw++) {
                            #pragma HLS UNROLL
                            int ih = oh * STRIDE + kh;
                            int iw = ow * STRIDE + kw;
                            acc += in_buf[ic][ih][iw] * weights[oc][ic][kh][kw];
                        }
                    }
                }
                out_stream.write((data_t)acc);
            }
        }
    }
}

// ---------------------------------------------------------------
// Depthwise Conv2D (groups = IN_C, one KxK filter per channel)
// PAD is explicit for the same reason as conv2d_layer above.
// ---------------------------------------------------------------
template<int IN_H, int IN_W, int C, int K, int STRIDE, int PAD>
void depthwise_conv2d_layer(
    hls::stream<data_t> &in_stream,
    hls::stream<data_t> &out_stream,
    const weight_t weights[C][K][K],
    const data_t bias[C])
{
    const int PAD_H = IN_H + 2 * PAD;
    const int PAD_W = IN_W + 2 * PAD;
    const int OUT_H = (IN_H + 2 * PAD - K) / STRIDE + 1;
    const int OUT_W = (IN_W + 2 * PAD - K) / STRIDE + 1;

    data_t in_buf[C][PAD_H][PAD_W];
    #pragma HLS BIND_STORAGE variable=in_buf type=ram_2p impl=bram
    #pragma HLS ARRAY_PARTITION variable=in_buf dim=1 type=complete

    for (int c = 0; c < C; c++) {
        for (int h = 0; h < PAD_H; h++) {
            for (int w = 0; w < PAD_W; w++) {
                #pragma HLS PIPELINE II=1
                bool is_pad = (h < PAD) || (h >= PAD + IN_H) ||
                              (w < PAD) || (w >= PAD + IN_W);
                in_buf[c][h][w] = is_pad ? (data_t)0 : in_stream.read();
            }
        }
    }

    for (int c = 0; c < C; c++) {
        for (int oh = 0; oh < OUT_H; oh++) {
            for (int ow = 0; ow < OUT_W; ow++) {
                #pragma HLS PIPELINE II=1
                acc_t acc = bias[c];
                for (int kh = 0; kh < K; kh++) {
                    for (int kw = 0; kw < K; kw++) {
                        #pragma HLS UNROLL
                        int ih = oh * STRIDE + kh;
                        int iw = ow * STRIDE + kw;
                        acc += in_buf[c][ih][iw] * weights[c][kh][kw];
                    }
                }
                out_stream.write((data_t)acc);
            }
        }
    }
}

// ---------------------------------------------------------------
// Pointwise (1x1) Conv2D — the core channel-mixing op
// No padding needed: K=1 makes padding a no-op.
// ---------------------------------------------------------------
template<int IN_H, int IN_W, int IN_C, int OUT_C>
void pointwise_conv2d_layer(
    hls::stream<data_t> &in_stream,
    hls::stream<data_t> &out_stream,
    const weight_t weights[OUT_C][IN_C],
    const data_t bias[OUT_C])
{
    #pragma HLS ARRAY_PARTITION variable=weights dim=2 type=complete

    data_t in_buf[IN_C][IN_H][IN_W];
    #pragma HLS BIND_STORAGE variable=in_buf type=ram_2p impl=bram
    #pragma HLS ARRAY_PARTITION variable=in_buf dim=1 type=complete

    for (int c = 0; c < IN_C; c++)
        for (int h = 0; h < IN_H; h++)
            for (int w = 0; w < IN_W; w++) {
                #pragma HLS PIPELINE II=1
                in_buf[c][h][w] = in_stream.read();
            }

    for (int oc = 0; oc < OUT_C; oc++) {
        for (int h = 0; h < IN_H; h++) {
            for (int w = 0; w < IN_W; w++) {
                #pragma HLS PIPELINE II=1
                acc_t acc = bias[oc];
                for (int ic = 0; ic < IN_C; ic++) {
                    #pragma HLS UNROLL factor=8
                    acc += in_buf[ic][h][w] * weights[oc][ic];
                }
                out_stream.write((data_t)acc);
            }
        }
    }
}

// ---------------------------------------------------------------
// Residual Add: out = x + conv(x), elementwise over the stream
// ---------------------------------------------------------------
template<int IN_H, int IN_W, int C>
void residual_add_layer(
    hls::stream<data_t> &skip_stream,
    hls::stream<data_t> &conv_stream,
    hls::stream<data_t> &out_stream)
{
    const int N = IN_H * IN_W * C;
    for (int i = 0; i < N; i++) {
        #pragma HLS PIPELINE II=1
        out_stream.write(skip_stream.read() + conv_stream.read());
    }
}

// ---------------------------------------------------------------
// Stream passthrough/tee — duplicates a stream for residual paths
// ---------------------------------------------------------------
template<int IN_H, int IN_W, int C>
void stream_split(
    hls::stream<data_t> &in_stream,
    hls::stream<data_t> &out_a,
    hls::stream<data_t> &out_b)
{
    const int N = IN_H * IN_W * C;
    for (int i = 0; i < N; i++) {
        #pragma HLS PIPELINE II=1
        data_t v = in_stream.read();
        out_a.write(v);
        out_b.write(v);
    }
}

#endif // LAYERS_H