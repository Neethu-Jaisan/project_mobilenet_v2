#ifndef CONV2D_H
#define CONV2D_H

#include "common.h"
#include <hls_stream.h>

// This prototype tells the compiler that conv2d_layer exists
void conv2d_layer(hls::stream<data_t>& in_stream, hls::stream<data_t>& out_stream);

#endif