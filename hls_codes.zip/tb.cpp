#include <iostream>
#include "conv2d.h" // Ensure this relative path matches your directory structure
#include "test_data.h"



int main() {
    hls::stream<data_t> in_stream, out_stream;
    
    // Feed the stream
    for(int i = 0; i < 864; i++) in_stream.write((data_t)test_input[i]);
    
    // Call your kernel
    conv2d_layer(in_stream, out_stream);
    
    // Verify results
    // ... verification logic ...
    return 0;
}