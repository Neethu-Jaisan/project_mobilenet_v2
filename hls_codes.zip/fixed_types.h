// fixed_types.h
#ifndef FIXED_TYPES_H
#define FIXED_TYPES_H

#include <ap_fixed.h>

typedef ap_fixed<16,6> data_t;
typedef ap_fixed<16,6> weight_t;
typedef ap_fixed<32,12> accum_t;

#endif